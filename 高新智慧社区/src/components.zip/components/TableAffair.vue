<template>
    <div style="width:100%;">
        <el-table
      :data="tableData" 
      border
      style="width: 100%"
      :default-sort = "{prop: 'date', order: 'descending'}"
      >
      <el-table-column
        prop="pno"
        label="问题编号"
        sortable
        width="120">
      </el-table-column>
      <el-table-column
        prop="ptype"
        label="问题类型"
        sortable
        width="120">
      </el-table-column>
      <el-table-column
        prop="pstate"
        label="处理状态"
        sortable
        width="120"
        >
      </el-table-column>
      <el-table-column
        prop="pdate1"
        label="上报时间"
       sortable
       width="200">
      </el-table-column>
      <el-table-column
        prop="pdate2"
        label="处理时间"
        width="200">
      </el-table-column>
      <el-table-column
        prop="pdes"
        label="问题描述"
        width="400">
      </el-table-column>
      <el-table-column
        prop="pname"
        label="上报用户"
        width="100"
        >
      </el-table-column>
      <el-table-column
   
      label="操作"
      width="150">
      <template slot-scope="scope">
        <el-button @click="handleClick(scope.row)" type="text" size="small">下载附件</el-button>
        <el-button type="text" size="small">提醒物业</el-button>
      </template>
    </el-table-column>
    </el-table>
    </div>

  </template>
  
  <script>
 export default {
    data() {
      return {
        tableData: [{
          date: '2016-05-02',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄'
        }, {
          date: '2016-05-04',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1517 弄'
        }, {
          date: '2016-05-01',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1519 弄'
        }, {
          date: '2016-05-03',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1516 弄'
        }]
      }
    },
    methods: {
      formatter(row,) {
        return row.address;
      }
    }
  }
  </script>