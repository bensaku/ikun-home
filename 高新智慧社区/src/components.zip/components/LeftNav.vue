 
  <template>
    <div class="sidebar">
        <img src="../assets/img/sos 安全管家2.png" style="width:200px;height: 200px; margin:0 auto; margin-bottom: 40px;" alt="">
      <ul>
        <li v-for="(item, index) in menuItems" :key="index" :class="{ active: item.active }">
          <router-link :to="item.url" @click="handleItemClick(index)">
            <img :src="item.icon" alt="Icon">
            {{ item.label }}
          </router-link>
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        menuItems: [
          { label: '首页', url: '/index', icon: require('../assets/img/首页 (1).png') },
          { label: '房屋管理', url: '/house', icon: require('../assets/img/房屋 (1).png')},
          { label: '车辆管理', url: '/car', icon: require('../assets/img/车辆 (1).png') },
          { label: '家人管理', url: '/family', icon: require('../assets/img/好友 (1).png') },
          { label: '问题上报', url: '/problem', icon: require('../assets/img/常见问题／相关问题 (1).png') },
          { label: '预算支出投票', url: '/budget', icon: require('../assets/img/投票 (1).png') },
          { label: '投诉', url: '/complain', icon: require('../assets/img/投诉 (1).png') },
        ],
      };
    },
    methods: {
      handleItemClick(index) {
        this.menuItems.forEach((item, i) => {
          item.active = i === index;
        });
      },
    },
  };
  </script>
  
  <style>
  .sidebar {
    background-color:#51594E;
    height: 100%;
    text-align: center;
  }
  
  .sidebar ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
  }

  .sidebar a {
  display: flex;
  font-size: 30px;
  color: white;
  height: 70px;
  align-items: center;
  text-decoration: none;
  } 
  .sidebar li {
    width: 100%;
    margin: 0;
    height: 70px;
  }
  
 .sidebar ul img {
    width: 45px; 
    height: 45px; 
    margin-right: 15px; 
    margin-left: 30px; 
  }
  .router-link-exact-active  {
  font-weight: bold;
  color: #333333 !important;
  background-color:#BBD90F;
}
  </style>
  