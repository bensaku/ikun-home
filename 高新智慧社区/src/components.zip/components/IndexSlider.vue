<template>
    <div class="block">
      <el-carousel height="900px">
        <el-carousel-item v-for="item in items" :key="item">
        <el-image :src="item.imageUrl" style="width:1560px;" alt="Carousel Image" />
      
        </el-carousel-item>
      </el-carousel>
    </div>
  </template>

  <script>
  export default {
    data() {
      return {
        items: [
          { imageUrl: require('../assets/img/小区2.jpg'), title: 'Image 1' },
          { imageUrl: require('../assets/img/小区3.jpg'), title: 'Image 2' },
          { imageUrl: require('../assets/img/小区3.jpeg'), title: 'Image 3' },
          { imageUrl: require('../assets/img/小区4.jpg'), title: 'Image 4' }
        ]
      };
    }
  };
  </script>
  
  <style>
    .el-carousel__item h3 {
      color: #475669;
      font-size: 14px;
      opacity: 0.75;
      line-height: 150px;
      margin: 0;
    }
  
    .el-carousel__item:nth-child(2n) {
       background-color: #99a9bf;
    }
    
    .el-carousel__item:nth-child(2n+1) {
       background-color: #d3dce6;
    }
  </style>
  