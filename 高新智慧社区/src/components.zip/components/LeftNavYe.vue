 
  <template>
    <div class="sidebar">
        <img src="../assets/img/sos 安全管家2.png" style="width:200px;height: 200px; margin:0 auto; margin-bottom: 40px;" alt="">
      <ul>
        <li v-for="(item, index) in menuItems" :key="index" :class="{ active: item.active }">
          <router-link :to="item.url" @click="handleItemClick(index)">
            <img :src="item.icon" alt="Icon">
            {{ item.label }}
          </router-link>
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        menuItems: [
          { label: '首页', url: '/indexYe', icon: require('../assets/img/首页 (1).png') },
          { label: '事项处置管理', url: '/affair', icon: require('../assets/img/常见问题／相关问题 (1).png')},
          { label: '投票统计管理', url: '/tongji', icon: require('../assets/img/投票 (1).png') },
          { label: '投诉建议管理', url: '/suggestion', icon: require('../assets/img/好友 (1).png') }
        ],
      };
    },
    methods: {
      handleItemClick(index) {
        this.menuItems.forEach((item, i) => {
          item.active = i === index;
        });
      },
    },
  };
  </script>
  
  <style>
  .sidebar {
    background-color:#51594E;
    height: 100%;
    text-align: center;
  }
  
  .sidebar ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
  }

  .sidebar a {
  display: flex;
  font-size: 30px;
  color: white;
  height: 70px;
  align-items: center;
  text-decoration: none;
  } 
  .sidebar li {
    width: 100%;
    margin: 0;
    height: 70px;
  }
  
 .sidebar ul img {
    width: 45px; 
    height: 45px; 
    margin-right: 15px; 
    margin-left: 30px; 
  }
  .router-link-exact-active  {
  font-weight: bold;
  color: #333333 !important;
  background-color:#BBD90F;
}
  </style>
  