<template>
    <div style="width: 100%;">
        <el-table
      :data="tableData"
      border
      style="width: 100%"
      :default-sort = "{prop: 'date', order: 'descending'}"
      >
      <el-table-column
        prop="cno"
        label="投诉编号"
        sortable
        width="120">
      </el-table-column>
      <el-table-column
        prop="cstate"
        label="处理状态"
        sortable
        width="120">
      </el-table-column>
      <el-table-column
        prop="cdate1"
        label="上报时间"
       sortable
       width="200">
      </el-table-column>
      <el-table-column
        prop="cdate2"
        label="处理时间"
        width="200">
      </el-table-column>
      <el-table-column
        prop="cdes"
        label="问题描述"
        width="400">
      </el-table-column>
      <el-table-column
        prop="pname"
        label="上报用户"
        width="100"
        >
      </el-table-column>
      <el-table-column
        prop="cdes"
        label="问题描述"
        width="200">
      </el-table-column>
      <el-table-column

      label="操作"
      width="100">
      <template >
        <el-button type="text" size="small">提醒物业</el-button>
      </template>
    </el-table-column>
    </el-table>
    </div>

  </template>
  
  <script>
 export default {
    data() {
      return {
        tableData: [{
          date: '2016-05-02',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1518 弄'
        }, {
          date: '2016-05-04',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1517 弄'
        }, {
          date: '2016-05-01',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1519 弄'
        }, {
          date: '2016-05-03',
          name: '王小虎',
          address: '上海市普陀区金沙江路 1516 弄'
        }]
      }
    },
    methods: {
      formatter(row,) {
        return row.address;
      }
    }
  }
  </script>