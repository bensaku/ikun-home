<template>
    <div >
<el-menu 
  :default-active="activeIndex2"
  class="el-menu-demo"
  mode="horizontal"
  @select="handleSelect"
  background-color="#51594E"
  text-color="#fff"
  style="border:0px;"
  active-text-color="#ffd04b">
  <el-submenu style="float: right;" index="2">
    <template slot="title"><img style="height: 30px; margin-right: 10px;font-size: 20px;" src="../assets/img/我的.png" alt="">蒋逸超</template>
    <div style="padding: 10px; color: #FFFFFF; font-size: 13px;">
        登录以:  
        <input type="radio" value="option1" v-model="selectedOption" /> 业主
        <input type="radio" value="option2" v-model="selectedOption" /> 业委会
    </div>
    <el-menu-item style="display: flex; justify-content: center;align-items: center;" index="2-2">退出登录</el-menu-item>
   
  </el-submenu>

  <el-menu-item style="float: right;" index="1" ><img style="height: 30px; margin-right: 10px;" src="../assets/img/信封_填充.png" alt=""></el-menu-item>
  <el-menu-item style="float: right;"  index="3"><img style="height: 30px; margin-right: 10px;" src="../assets/img/211铃铛.png" alt=""></el-menu-item>
 
  
</el-menu>
<div style="height: 20px;background-color:#BBD90F;"></div>
    </div>
</template>



<script>
  export default {
    data() {
      return {
        activeIndex: '1',
        activeIndex2: '1',
        selectedOption: 'option1'
      };
    },
    methods: {
      handleSelect(key, keyPath) {
        console.log(key, keyPath);
      }
    }
  }
</script>
