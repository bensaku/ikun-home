<template>
  <div style="position:absolute;right:0;top: 80px;height: 100px;width:80%;z-index: 1;">
  <div class="card" id="car_card_zhengchang">
      <div class="card-left">
      <h2 class="card-title">
        我的车辆
        <img class="card-icon" src="../assets/img/汽车.png"/>
      </h2>
      <div class="card-data">
        <div class="row">
          <label for="leftData1">车辆信息</label>
        </div>
        <div class="spacer"></div> <!-- 间隔元素 -->
        <div class="row">
          <label for="leftData1">车辆型号:</label>
          <input class="card-input" type="text" v-model="car_detial1" :readonly="isReadOnly"/>
        </div>
        <div class="row">
          <label for="leftData1">车牌号:</label>
          <input class="card-input" type="text" v-model="car_no1" :readonly="isReadOnly"/>
        </div>
      </div>
    </div>
    <div class="card-right">
      <h2 class="card-title">
        我的车位
        <img class="card-icon" src="../assets/img/停车场.png"/>
      </h2>
        <div class="row">
          <label for="leftData1">车位信息</label>
        </div>
        <div class="spacer"></div> <!-- 间隔元素 -->
        <div class="row">
          <label for="leftData1">位置:</label>
          <input class="card-input" type="text" v-model="location1" :readonly="isReadOnly"/>
          <label for="leftData1">编号:</label>
          <input class="card-input" type="text" v-model="car_pote1" :readonly="isReadOnly"/>
        </div>
        <div class="row">
          <label for="leftData1">到期时间:</label>
          <input class="card-input" type="text" v-model="car_time1" :readonly="isReadOnly"/>
          <a href="#" class="my-link" @click="showModal">续租</a>
        </div>
    </div>
  </div>

  <div class="card" id="car_card_guoqi">
      <div class="card-left">
      <h2 class="card-title">
        我的车辆
        <img class="card-icon" src="../assets/img/汽车.png"/>
      </h2>
      <div class="card-data">
        <div class="row">
          <label for="leftData1">车辆信息</label>
        </div>
        <div class="spacer"></div> <!-- 间隔元素 -->
        <div class="row">
          <label for="leftData1">车辆型号:</label>
          <input class="card-input" type="text" v-model="car_detial2" :readonly="isReadOnly"/>
        </div>
        <div class="row">
          <label for="leftData1">车牌号:</label>
          <input class="card-input" type="text" v-model="car_no2" :readonly="isReadOnly"/>
        </div>
      </div>
    </div>
    <div class="card-right">
      <h2 class="card-title4">
        我的车位
        <img class="card-icon" src="../assets/img/停车场 (1).png"/>
        <div class="rotated2">已到期</div>
      </h2>
        <div class="row">
          <label for="leftData1">车位信息</label>
        </div>
        <div class="spacer"></div> <!-- 间隔元素 -->
        <div class="row">
          <label for="leftData1">位置:</label>
          <input class="card-input" type="text" v-model="location2" :readonly="isReadOnly"/>
          <label for="leftData1">编号:</label>
          <input class="card-input" type="text" v-model="car_pote2" :readonly="isReadOnly"/>
        </div>
        <div class="row">
          <label for="leftData1">到期时间:</label>
          <input class="card-input" type="text" v-model="car_time2" :readonly="isReadOnly"/>
          <a href="#" class="my-link" @click="showModal">续租</a>
        </div>
    </div>
  </div>

  <div class="card" id="car_card_jijiang">
      <div class="card-left">
      <h2 class="card-title">
        我的车辆
        <img class="card-icon" src="../assets/img/汽车.png"/>
      </h2>
      <div class="card-data">
        <div class="row">
          <label for="leftData1">车辆信息</label>
        </div>
        <div class="spacer"></div> <!-- 间隔元素 -->
        <div class="row">
          <label for="leftData1">车辆型号:</label>
          <input class="card-input" type="text" v-model="car_detial3" :readonly="isReadOnly"/>
        </div>
        <div class="row">
          <label for="leftData1">车牌号:</label>
          <input class="card-input" type="text" v-model="car_no3" :readonly="isReadOnly"/>
        </div>
      </div>
    </div>
    <div class="card-right">
      <h2 class="card-title3">
        我的车位
        <img class="card-icon" src="../assets/img/停车场 (2).png"/>
        <div class="rotated1">即将到期</div>
      </h2>
        <div class="row">
          <label for="leftData1">车位信息</label>
        </div>
        <div class="spacer"></div> <!-- 间隔元素 -->
        <div class="row">
          <label for="leftData1">位置:</label>
          <input class="card-input" type="text" v-model="location3" :readonly="isReadOnly"/>
          <label for="leftData1">编号:</label>
          <input class="card-input" type="text" v-model="car_pote3" :readonly="isReadOnly"/>
        </div>
        <div class="row">
          <label for="leftData1">到期时间:</label>
          <input class="card-input" type="text" v-model="car_time3" :readonly="isReadOnly"/>
          <a href="#" class="my-link" @click="showModal">续租</a>
        </div>
    </div>
  </div>


  <div class="card_faqi" id="car_card_tianjia">
    <div class="card-left">
      <h2 class="card-title2">
        添加车辆
        <img class="card-icon" src="../assets/img/汽车 (1).png"/>
      </h2>
      <div class="card-data_faqi">
        <h>点击右侧按钮添加车辆</h>
      </div>
    </div>
    <div class="card-right">
      <button class="card-button" @click="showModal">
          <img class="card-button-image" src="../assets/img/增加.png"/>
        </button>
        
      </div>
      </div>


  <div class="card_faqi" id="car_card_tianjia">
    <div class="card-left">
      <h2 class="card-title4">
        您尚未绑定房屋
        <img class="card-icon" src="../assets/img/307感叹号-三角框.png"/>
      </h2>
      <div class="card-data_faqi">
        <h>绑定房屋后方可添加车辆，点击右侧按钮转跳至绑定房屋页面</h>
      </div>
    </div>
    <div class="card-right">
      <button class="card-button" >
        <img class="card-button-image" src="../assets/img/房屋.png"/>
      </button>
    </div>
  </div>

  <div class="modal2" v-if="isModalVisible">
          <h2 class="modal-label1">新增车辆信息</h2>
          <div class="modal-row">
            <label class="modal-row-label1">车牌号：</label>
            <input class="modal-row-input" type="text" v-model="car_no4" />
          </div>
          <div class="modal-row">
            <label class="modal-row-label1">车辆型号：</label>
            <input class="modal-row-input" type="text" v-model="car_detail4" />
          </div>
          <div class="modal-content">
            <label for="dropdown" class="dropdownlabel">选择房产：</label>
            <select id="dropdown" v-model="selectedOption" class="dropdownselect">
              <option value="" disabled selected hidden>请选择您的房产</option>
              <option v-for="option in dropdownOptions" :key="option.value" :value="option.value">{{ option.label }}</option>
            </select>
          </div>
          <div class="modal-row">
            <label class="modal-row-label1">车位号：</label>
            <input class="modal-row-input" type="text" v-model="car_pote4" />
          </div>
          <div class="row-m">
          <div class="modal-row-m">
            <label class="modal-row-label2">租赁年限:</label>
            <input class="modal-row-input1" type="text" v-model="car_time4" />
            <span class="modal-row-unit">年</span>
          </div>
          <div class="modal-row-m">
            <label class="modal-row-label3">金额:</label>
            <input class="modal-row-input1" type="text" v-model="car_charge4" :readonly="isReadOnly"/>
            <span class="modal-row-unit">元</span>
          </div>  
          </div>
          <div class="modal-buttons">
            <button class="modal-button1" @click="doinsert">确认</button>
            <button class="modal-button2" @click="closeModal">取消</button>
          </div>
        </div>



  <div class="modal3" v-if="isModalVisible2">
          <h2 class="modal-label1">续租车辆信息</h2>
          <div class="modal-row">
            <label class="modal-row-label1">车牌号：</label>
            <input class="modal-row-input" type="text" v-model="car_no5" />
          </div>
          <div class="modal-row">
            <label class="modal-row-label1">车辆型号：</label>
            <input class="modal-row-input" type="text" v-model="car_detail5" />
          </div>
          <div class="modal-row">
            <label class="modal-row-label1">车位号：</label>
            <input class="modal-row-input" type="text" v-model="car_pote5" />
          </div>
          <div class="row-m">
            <div class="modal-row-m">
            <label class="modal-row-label2">续租年限:</label>
            <input class="modal-row-input1" type="text" v-model="car_time5" />
            <span class="modal-row-unit">年</span>
            </div>
            <div class="modal-row-m">
            <label class="modal-row-label3">金额:</label>
            <input class="modal-row-input1" type="text" v-model="car_charge5" />
            <span class="modal-row-unit">元</span>
            </div>
          </div>
          <div class="modal-row">
            <label class="modal-row-label1">到期时间：</label>
            <input class="modal-row-input" type="text" v-model="complaintTitle3" />
          </div>
          <div class="modal-buttons">
            <button class="modal-button1" @click="submitComplaint2">确认</button>
            <button class="modal-button2" @click="closeModal2">取消</button>
          </div>
        </div>

</div>



</template>

<script>
export default {
  data() {
    return {
      car_detial1:'IKUN鸡你太美A级',
      car_no1:'CTRAP',
      car_pote1:'C001',
      car_time1:'2024/1/1',
      location1:'IKUN花园A区',
      car_detial2:'IKUN鸡你太美B级',
      car_no2:'CTRAPl',
      car_pote2:'C001',
      car_time2:'2023/1/1',
      location2:'IKUN花园A区',
      car_detial3:'IKUN鸡你太美C级',
      car_no3:'CTRAPll',
      car_pote3:'C001',
      car_time3:'2023/7/1',
      location3:'IKUN花园A区',
      isReadOnly: true,
      isModalVisible: false,
      isModalVisible2: false,
      selectedOption: '',
      dropdownOptions: [
      { label: '选项1', value: 'option1' },
      { label: '选项2', value: 'option2' },
      { label: '选项3', value: 'option3' }
      ],
      car_detial4:'',
      car_no4:'',
      car_pote4:'',
      car_time4:'',
      car_charge4:'',
      car_detial5:'',
      car_no5:'',
      car_pote5:'',
      car_time5:'',
      car_charge5:'',

    };
  },
  methods: {
    showModal() {
          this.isModalVisible = true;
        },
        closeModal() {
          this.isModalVisible = false;
        },
        doinsert() {
          if (!this.car_no4) {
          this.$message.error("请输入车牌！");
          return;
        }
        if (!this.car_detail4) {
          this.$message.error("请输入车辆型号！");
          return;
        }
        if (!this.selectedOption) {
          this.$message.error("请选择您的房产！");
          return;
        }
        if (!this.car_pote4) {
          this.$message.error("请输入车位号！");
          return;
        }
        if (!this.car_time4) {
          this.$message.error("请输入续租年限！");
          return;
        }
        },
        showModal2() {
          this.isModalVisible2 = true;
        },
        closeModal2() {
          this.isModalVisible2 = false;
        },
        submitComplaint2() {
          // 处理投诉提交逻辑
        }
  }
};

</script>
<style>
  @import "../assets/style/card.css";

  .rotated1 {
  transform: rotate(45deg);
  font-size: 15px;
  border: 2px dashed #E87D00;
  border-radius: 5px;
}

.rotated2 {
  transform: rotate(45deg);
  font-size: 15px;
  border: 2px dashed #A30014;
  border-radius: 5px;
}
    
    .modal2 {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #fff;
    width: 360px;
    height: 320px;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  }
  
  .modal2 .modal-label1 {
    text-align: center;
    font-size: 25px;
    color: #667561;
    font-weight: bold;
    margin-top: 2px;
    margin-bottom: 10px;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
  }
  .modal2 .modal-row {
    display: flex;
    align-items: center;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .modal2 .row-m {
    display: flex;
    align-items: center;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .modal2 .modal-row-label1 {
    flex: 0 0 100px;
    font-weight: bold;
    color: #667561;
  }
  .modal2 .modal-row-label2 {
    flex: 0 0 100px;
    font-weight: bold;
    color: #667561;
  }
  .modal2 .modal-row-label3 {
    flex: 0 0 100px;
    font-weight: bold;
    color: #667561;
    margin-left: 55px;
  }
  /*下拉框*/
  .modal2 .modal-content {
    display: flex;
    align-items: center;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .modal2 .dropdownlabel{
    flex: 0 0 100px;
    font-weight: bold;
    color: #667561;
  }
  .modal2 .dropdownselect{
    flex: 1;
    height: 25px;
    margin-left: -15px;
    margin-right: 55px;
    border-radius: 4px;
    border: 2px solid #9c9c9c;
  }
  .modal2 .modal-row-input {
    flex: 1;
    height: 25px;
    margin-left: -15px;
    margin-right: 55px;
    border-radius: 4px;
    border: 2px solid #9c9c9c;
  }
  .modal2 .modal-row-input1 {
    flex: 1;
    margin-left: 15px;
    width: 50px;
    border-radius: 4px;
    border: 2px solid #9c9c9c;
  }
  
  .modal2 .modal-row-unit {
    margin-left: 5px;
  }
  
  .modal2 .modal-buttons {
    text-align: center;
    margin-bottom: 0%;
    border-radius: 5px;
  }
  
  .modal2 .modal-button1 {
    margin: 10px;
    margin-bottom: 5px;
    background-color: #667561;
    color: #fff;
  }
  .modal2 .modal-button1:hover{
    background-color: #2e312d;
  }
  .modal2 .modal-button2 {
    margin: 10px;
    margin-bottom: 10px;
  }
  
    /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~车位 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    
    .modal3 {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #fff;
    width: 360px;
    height: 320px;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  }
  
  .modal3 .modal-label1 {
    text-align: center;
    font-size: 25px;
    color: #667561;
    font-weight: bold;
    margin-top: 2px;
    margin-bottom: 10px;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
  }
  .modal3 .modal-row {
    display: flex;
    align-items: center;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .modal3 .row-m {
    display: flex;
    align-items: center;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .modal3 .modal-row-label1 {
    flex: 0 0 100px;
    font-weight: bold;
    color: #667561;
  }
  .modal3 .modal-row-label2 {
    flex: 0 0 100px;
    font-weight: bold;
    color: #667561;
  }
  .modal3 .modal-row-label3 {
    flex: 0 0 100px;
    font-weight: bold;
    color: #667561;
    margin-left: 55px;
  }
  .modal3 .modal-row-input {
    flex: 1;
    height: 25px;
    margin-left: -15px;
    margin-right: 55px;
    border-radius: 4px;
    border: 2px solid #9c9c9c;
  }
  .modal3 .modal-row-input1 {
    flex: 1;
    margin-left: 15px;
    width: 50px;
    border-radius: 4px;
    border: 2px solid #9c9c9c;
  }
  
  .modal3 .modal-row-unit {
    margin-left: 5px;
  }
  
  .modal3 .modal-buttons {
    text-align: center;
    margin-bottom: 0%;
    border-radius: 5px;
  }
  
  .modal3 .modal-button1 {
    margin: 10px;
    margin-bottom: 5px;
    background-color: #667561;
    color: #fff;
  }
  .modal3 .modal-button1:hover{
    background-color: #2e312d;
  }
  .modal3 .modal-button2 {
    margin: 10px;
    margin-bottom: 10px;
  }
  .modal-lastrow{
    display: flex;
    align-items: center;
    margin-top: 20px;
    margin-bottom: 20px;
  }
    </style>
