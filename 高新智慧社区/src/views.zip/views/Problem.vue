<template>
    <div style="position:absolute;right:0;top: 80px;height: 100px;width:80%;z-index: 1;">
    <div class="problem-card" id="problem_card_finish">
        <div class="card-left">
        <h2 class="card-title">
          我的问题
          <img class="card-icon" src="../assets/img/问题 (1).png"/>
        </h2>
        <div class="card-data">
          <div class="row">
            <label for="leftData1">问题编号:</label>
            <input class="card-input" type="text" v-model="problem_no1" :readonly="isReadOnly"/>
          </div>
          <div class="row">
            <label for="leftData1">问题类型:</label>
            <input class="card-input" type="text" v-model="problem_type1" :readonly="isReadOnly"/>
          </div>
          <div class="row">
            <label for="leftData1">问题描述:</label>
            <textarea class="card-input2" type="text" v-model="problem_detail1" :readonly="isReadOnly"></textarea>
          </div>
        </div>
      </div>
      <div class="card-right">
        <h2 class="card-title">
          目前状态:
        <input class="card-input1" v-model="problem_state1" :readonly="isReadOnly"/>
        </h2>
          <div class="row">
            <label for="leftData1">上报时间:</label>
            <input class="card-input" type="text" v-model="starttime1" :readonly="isReadOnly"/>
            <label for="leftData1">解决时间:</label>
            <input class="card-input" type="text" v-model="endtime1" :readonly="isReadOnly"/>
          </div>
          <div class="row">
            <label for="leftData1">附件:</label>
            <img class="card-icon" src="../assets/img/附件 (1).png"/>
          </div>
      </div>
    </div>
  
    <div class="problem-card" id="problem_card_weiwancheng">
        <div class="card-left">
        <h2 class="card-title">
          我的问题
          <img class="card-icon" src="../assets/img/问题 (1).png"/>
        </h2>
        <div class="card-data">
          <div class="row">
            <label for="leftData1">问题编号:</label>
            <input class="card-input" type="text" v-model="problem_no2" :readonly="isReadOnly"/>
          </div>
          <div class="row">
            <label for="leftData1">问题类型:</label>
            <input class="card-input" type="text" v-model="problem_type2" :readonly="isReadOnly"/>
          </div>
          <div class="row">
            <label for="leftData1">问题描述:</label>
            <textarea class="card-input2" type="text" v-model="problem_detail2" :readonly="isReadOnly"></textarea>
          </div>
        </div>
      </div>
      <div class="card-right">
        <h2 class="card-title3">
          目前状态:
        <input class="card-input4" v-model="problem_state2" :readonly="isReadOnly"/>
        </h2>
          <div class="row">
            <label for="leftData1">上报时间:</label>
            <input class="card-input" type="text" v-model="starttime2" :readonly="isReadOnly"/>
            <label for="leftData1">解决时间:</label>
            <input class="card-input" type="text" v-model="endtime2" :readonly="isReadOnly"/>
          </div>
          <div class="row">
            <label for="leftData1">附件:</label>
            <img class="card-icon" src="../assets/img/附件 (1).png"/>
          </div>
      </div>
    </div>
  
  
    <div class="card_faqi" id="problem_card_faqi">
      <div class="card-left">
        <h2 class="card-title2">
          发起问题
          <img class="card-icon" src="../assets/img/问题 (2).png"/>
        </h2>
        <div class="card-data_faqi">
          <h>点击右侧按钮发起问题</h>
        </div>
    </div>
    <div class="card-right">
      <button class="card-button" @click="showModal">
        <img class="card-button-image" src="../assets/img/增加.png"/>
      </button>
      <div class="modal" v-if="isModalVisible">
        <h2 class="modal-label1">问题</h2>
        <div class="modal-row">
          <label class="modal-row-label2">问题描述：</label>
        </div>
        <div class="textarea-row">
          <textarea class="modal-row-textarea" v-model="problemdetail"></textarea>
        </div>        
        <div class="file-upload">
    <label for="fileInput" class="file-input-label">
      <span class="select-file-text">{{ selectedFileName || '上传附件' }}</span>
      <input type="file" id="fileInput" class="file-input" @change="handleFileChange" />
    </label>
  </div>
        <div class="modal-buttons">
          <button class="modal-button1" @click="doinsert">确认</button>
          <button class="modal-button2" @click="closeModal">取消</button>
        </div>
      </div>
    </div>
  </div>
</div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        problem_no1:'0001',
        problem_type1: '生活用电',
        problem_detail1: '小区经常停电',
        problem_state1: '已处理',
        starttime1:'2023.3.10',
        endtime1:'2023.3.20',
        problem_no2:'0002',
        problem_type2: '',
        problem_detail2: '',
        problem_state2: '未处理',
        starttime2:'',
        endtime2:'',
        isReadOnly: true,
        isModalVisible: false,
        selectedFile: null,
        selectedFileName: '',
        problemdetail:''
      };
    },
    methods: {
      showModal() {
      this.isModalVisible = true;
    },
    closeModal() {
      this.isModalVisible = false;
    },
    doinsert() {
        if (!this.problemdetail) {
          this.$message.error("请输入问题详情！");
          return;
        }
      },
    handleFileChange(event) {
      const file = event.target.files[0];
      if (file) {
        this.selectedFile = file;
        this.selectedFileName = file.name;
      } else {
        this.selectedFile = null;
        this.selectedFileName = '';
      }
    },
    }


  };
  
  </script>
  <style>
    @import "../assets/style/card.css";

    .file-upload {
  display: inline-block;
}

.file-input-label {
  display: inline-block;
  padding: 8px 20px;
  background-color: #70B603;
  color: #fff;
  border-radius: 4px;
  cursor: pointer;
}

.file-input {
  display: none;
}

.select-file-text {
  margin-right: 10px;
}

.selected-file-name {
  margin-top: 10px;
}
  </style>
  