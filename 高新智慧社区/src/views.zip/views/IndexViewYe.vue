<template>
    <div id="app" >
      <TopNav style="position:fixed;width:80%;left: 20%;z-index: 2;">
  
      </TopNav>
      <LeftNavYe style="position:fixed;width:20%;left:0;z-index: 3;">
  
      </LeftNavYe>
      <div style="position:absolute;right:0;left:20%;top: 80px;height:800px;width:80%;z-index: 1;">
        <IndexSlider></IndexSlider>
        <IndexNotice style="margin-top:20px ;margin-left: 30px;"></IndexNotice>
        
      </div>
    
    </div>
  </template>
  
  <script>
  import TopNav from '../components/TopNav.vue'
  import LeftNavYe from '../components/LeftNavYe.vue'
  import IndexSlider from '../components/IndexSlider.vue'
  import IndexNotice from '../components/IndexNotice.vue';
   export default {
     name: 'app',
     components: {
       TopNav,
       LeftNavYe,
       IndexSlider,
       IndexNotice
     }
   }
  </script>
  
  <style>
  body{
    margin: 0;
    padding: 0;
  }
  </style>