<template>
    <div style="position:absolute;right:0;top: 80px;height: 100px;width:80%;z-index: 1;">
        <!-- 展示卡片循环 -->
        <div v-for="vote in votes" :key="vote.id" @click="vote.showDitail = true">
            <template v-if="vote.status === '投票中'">
                <div>
                    <!-- 投票中 -->
                    <div class="voting-card">
                        <!-- 标题栏 -->
                        <div class="text">
                            <!-- 左侧图标 -->
                            <div class="left-title">
                                <img src="../assets/img/voting.png" width="85" height="85">
                            </div>

                            <!-- 右侧标题 -->
                            <div class="right-title">{{ vote.title }}</div>
                        </div>


                        <!-- 详细信息 -->
                        <div class="info">
                            <!-- 左侧文字信息 -->
                            <div class="details">
                                <span style="margin: 0;">截至日期：{{ vote.deadline }}</span>
                                <p style="float: left;">{{ vote.detail }}</p>

                                <p class="investment">事项预计投资：<span class="amount">{{ vote.budget }}</span>元</p>
                            </div>
                            <!-- 右侧投票区 -->
                            <div class="voting">
                                <!-- 两个按钮 -->
                                <div class="buttons">
                                    <button class="vote-button up" @click="vote(vote.id, 'up')">
                                        <img src="../assets/img/up.png" alt="up icon" width="60" height="60">
                                    </button>
                                    <button class="vote-button down" @click="vote(vote.id, 'down')">
                                        <img src="../assets/img/down.png" alt="down icon" width="60" height="60">
                                    </button>
                                </div>
                                <!-- 显示投票结果 -->
                                <span>支持率：</span>
                                <div :style="{ color: textColor, fontSize: textSize }" class="vote-percentage">{{
                                    Math.round((vote.supportCount / (vote.supportCount + vote.opposeCount)) * 100) }}%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </template>

            <template v-else-if="vote.status === '已通过'">
                <div>
                    <!-- 通过 -->
                    <div class="voting-card">
                        <!-- 标题栏 -->
                        <div class="text">
                            <!-- 左侧图标 -->
                            <div class="left-title">
                                <img src="../assets/img/pass.png" width="85" height="85">
                            </div>

                            <!-- 右侧标题 -->
                            <div class="right-title">{{ vote.title }}</div>
                        </div>


                        <!-- 详细信息 -->
                        <div class="info">
                            <!-- 左侧文字信息 -->
                            <div class="details">
                                <span style="margin: 0; color: red;">截至日期：{{ vote.deadline }}</span>
                                <p style="float: left;">{{ vote.detail }}</p>

                                <p class="investment">事项预计投资：<span class="amount">{{ vote.budget }}</span>元</p>
                            </div>
                            <!-- 右侧投票区 -->
                            <div class="voting">
                                <!-- 两个按钮 -->
                                <div class="buttons">
                                    <button class="vote-button up" @click="vote(vote.id, 'up')">
                                        <img src="../assets/img/up.png" alt="up icon" width="60" height="60">
                                    </button>
                                    <button class="vote-button down" @click="vote(vote.id, 'down')">
                                        <img src="../assets/img/down.png" alt="down icon" width="60" height="60">
                                    </button>
                                </div>
                                <!-- 显示投票结果 -->
                                <span>支持率：</span>
                                <div :style="{ color: textColor, fontSize: textSize }" class="vote-percentage">{{
                                    Math.round((vote.supportCount / (vote.supportCount + vote.opposeCount)) * 100) }}%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </template>

            <template v-else-if="vote.status === '未通过'">
                <div>
                    <!-- 未通过 -->
                    <div class="voting-card">
                        <!-- 标题栏 -->
                        <div class="text">
                            <!-- 左侧图标 -->
                            <div class="left-title">
                                <img src="../assets/img/notpass.png" width="85" height="85">
                            </div>

                            <!-- 右侧标题 -->
                            <div class="right-title">{{ vote.title }}</div>
                        </div>


                        <!-- 详细信息 -->
                        <div class="info">
                            <!-- 左侧文字信息 -->
                            <div class="details">
                                <span style="margin: 0; color: red;">截至日期：{{ vote.deadline }}</span>
                                <p style="float: left;">{{ vote.detail }}</p>

                                <p class="investment">事项预计投资：<span class="amount">{{ vote.budget }}</span>元</p>
                            </div>
                            <!-- 右侧投票区 -->
                            <div class="voting">
                                <!-- 两个按钮 -->
                                <div class="buttons">
                                    <button class="vote-button up" @click="vote(vote.id, 'up')">
                                        <img src="../assets/img/up.png" alt="up icon" width="60" height="60">
                                    </button>
                                    <button class="vote-button down" @click="vote(vote.id, 'down')">
                                        <img src="../assets/img/down.png" alt="down icon" width="60" height="60">
                                    </button>
                                </div>
                                <!-- 显示投票结果 -->
                                <span>支持率：</span>
                                <div :style="{ color: textColor, fontSize: textSize }" class="vote-percentage">{{
                                    Math.round((vote.supportCount / (vote.supportCount + vote.opposeCount)) * 100) }}%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </template>
        </div>


        <!-- 详细信息窗口 -->
        <div v-for="vote in votes" :key="vote.id">
            <template v-if="vote.status === '投票中' && vote.showDitail === true">
                <div>
                    <div class="details-card">
                        <div class="text">
                            <div class="left-title">
                                <img src="../assets/img/voting.png" width="85" height="85">
                            </div>
                            <div class="right-title">{{ vote.title }}</div>
                            <div class="close-details">
                                <button class="close-button" @click="vote.showDitail = false">
                                    <img src="../assets/img/叉叉.png" alt="chacha" width="40" height="40">
                                </button>
                            </div>
                        </div>


                        <div class="content">
                            <div class="details">
                                <span style="margin: 0; color: red;">截至日期：{{ vote.deadline }}</span>
                                <p style="float: left;">{{ vote.detail }}</p>
                            </div>
                        </div>

                        <div class="bottom-div">
                            <!-- 投资 -->
                            <p class="investment">事项预计投资：<span class="amount">{{ vote.budget }}</span>元</p>

                            <!-- 投票区 -->
                            <div class="voting">
                                <!-- 两个按钮 -->
                                <div class="buttons">
                                    <button class="vote-button up" @click="vote(vote.id, 'up')">
                                        <img src="../assets/img/up.png" alt="up icon" width="60" height="60">
                                    </button>
                                    <button class="vote-button down" @click="vote(vote.id, 'down')">
                                        <img src="../assets/img/down.png" alt="down icon" width="60" height="60">
                                    </button>
                                </div>
                                <!-- 显示投票结果 -->
                                <span>支持率：</span>
                                <div :style="{ color: textColor, fontSize: textSize }" class="vote-percentage">
                                    {{ Math.round((vote.supportCount / (vote.supportCount + vote.opposeCount)) * 100) }}%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </template>

            <template v-else-if="vote.status === '已通过' && vote.showDitail === true">
                <div>
                    <div class="details-card">
                        <div class="text">
                            <div class="left-title">
                                <img src="../assets/img/pass.png" width="85" height="85">
                            </div>
                            <div class="right-title">{{ vote.title }}</div>
                            <div class="close-details">
                                <button class="close-button" @click="vote.showDitail = false">
                                    <img src="../assets/img/叉叉.png" alt="chacha" width="40" height="40">
                                </button>
                            </div>
                        </div>


                        <div class="content">
                            <div class="details">
                                <span style="margin: 0; color: red;">截至日期：{{ vote.deadline }}</span>
                                <p style="float: left;">{{ vote.detail }}</p>
                            </div>
                        </div>

                        <div class="bottom-div">
                            <!-- 投资 -->
                            <p class="investment">事项预计投资：<span class="amount">{{ vote.budget }}</span>元</p>

                            <!-- 投票区 -->
                            <div class="voting">
                                <!-- 两个按钮 -->
                                <div class="buttons">
                                    <button class="vote-button up" @click="vote(vote.id, 'up')">
                                        <img src="../assets/img/up.png" alt="up icon" width="60" height="60">
                                    </button>
                                    <button class="vote-button down" @click="vote(vote.id, 'down')">
                                        <img src="../assets/img/down.png" alt="down icon" width="60" height="60">
                                    </button>
                                </div>
                                <!-- 显示投票结果 -->
                                <span>支持率：</span>
                                <div :style="{ color: textColor, fontSize: textSize }" class="vote-percentage">
                                    {{ Math.round((vote.supportCount / (vote.supportCount + vote.opposeCount)) * 100) }}%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </template>

            <template v-if="vote.status === '未通过' && vote.showDitail === true">
                <div>
                    <div class="details-card">
                        <div class="text">
                            <div class="left-title">
                                <img src="../assets/img/notpass.png" width="85" height="85">
                            </div>
                            <div class="right-title">{{ vote.title }}</div>
                            <div class="close-details">
                                <button class="close-button" @click="vote.showDitail = false">
                                    <img src="../assets/img/叉叉.png" alt="chacha" width="40" height="40">
                                </button>
                            </div>
                        </div>


                        <div class="content">
                            <div class="details">
                                <span style="margin: 0; color: red;">截至日期：{{ vote.deadline }}</span>
                                <p style="float: left;">{{ vote.detail }}</p>
                            </div>
                        </div>

                        <div class="bottom-div">
                            <!-- 投资 -->
                            <p class="investment">事项预计投资：<span class="amount">{{ vote.budget }}</span>元</p>

                            <!-- 投票区 -->
                            <div class="voting">
                                <!-- 两个按钮 -->
                                <div class="buttons">
                                    <button class="vote-button up" @click="vote(vote.id, 'up')">
                                        <img src="../assets/img/up.png" alt="up icon" width="60" height="60">
                                    </button>
                                    <button class="vote-button down" @click="vote(vote.id, 'down')">
                                        <img src="../assets/img/down.png" alt="down icon" width="60" height="60">
                                    </button>
                                </div>
                                <!-- 显示投票结果 -->
                                <span>支持率：</span>
                                <div :style="{ color: textColor, fontSize: textSize }" class="vote-percentage">
                                    {{ Math.round((vote.supportCount / (vote.supportCount + vote.opposeCount)) * 100) }}%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </template>
        </div>
    </div>
</template>

<script>
import axios from 'axios';



export default {
    data() {
        return {
            votes: [
                {
                    id: 1,
                    title: "标题1",
                    deadline: "2025年1月1日 8:00",
                    detail: "回访记录放寒假撒啊防火卷帘打开撒化肥就考虑到撒谎lhsdafjkl发送发",
                    status: "投票中",
                    budget: 10000,
                    supportCount: 1000,
                    opposeCount: 100,
                    showDitail: false
                },
                {
                    id: 2,
                    title: "标题2",
                    deadline: "2025年2月1日 8:00",
                    detail: "回访记录放寒假撒啊防火卷帘打开撒化肥就考虑到撒谎lhsdafjkl发送发",
                    status: "已通过",
                    budget: 10000,
                    supportCount: 10,
                    opposeCount: 100,
                    showDitail: false
                },
                {
                    id: 3,
                    title: "标题3",
                    deadline: "2025年3月1日 8:00",
                    detail: "回访记录放寒假撒啊防火卷帘打开撒化肥就考虑到撒谎lhsdafjkl发送发",
                    status: "未通过",
                    budget: 10000,
                    supportCount: 100,
                    opposeCount: 10,
                    showDitail: false
                },
                {
                    id: 4,
                    title: "标题4",
                    deadline: "2025年4月1日 8:00",
                    detail: "回访记录放寒假撒啊防火卷帘打开撒化肥就考虑到撒谎lhsdafjkl发送发",
                    status: "未通过",
                    budget: 10000,
                    supportCount: 50,
                    opposeCount: 100,
                    showDitail: false
                },
                {
                    id: 5,
                    title: "标题1",
                    deadline: "2025年1月1日 8:00",
                    detail: "回访记录放寒假撒啊防火卷帘打开撒化肥就考虑到撒谎lhsdafjkl发送发",
                    status: "投票中",
                    budget: 10000,
                    supportCount: 100,
                    opposeCount: 190,
                    showDitail: false
                }
            ],

            showDialog: false,
            // ddl: "2023年7月31日 24:00",
            Vote: {
                supportCount: 10,
                opposeCount: 5,
            },
        };
    },
    computed: {
        supportPrecentage() {
            if (this.Vote.supportCount === 0 && this.Vote.opposeCount === 0) {
                return 0;
            }
            return Math.round((this.Vote.supportCount / (this.Vote.supportCount + this.Vote.opposeCount)) * 100);
        },
        textColor() {
            return this.supportPrecentage >= 80 ? 'rgb(112,182,3)' : 'rgb(163,0,20)';
        },
        textSize() {
            return `${1 + (this.supportPrecentage / 100) * 2}em`;
        }
    },
    methods: {

        // vote(option) {
        //     // 处理投票逻辑
        //     // 在此示例中，只是简单地模拟投票行为并更新投票支持率
        //     if (option === 'up') {
        //         this.Vote.supportCount += 1;
        //     } else if (option === 'down') {
        //         this.Vote.opposeCount += 1;
        //     }
        // },
        vote(voteId, type) {
            // 根据投票ID找到对应的投票信息
            const vote = this.votes.find(vote => vote.id === voteId);

            // 根据type判断是支持还是反对，并更新相应的数值
            if (type === 'up') {
                vote.supportCount++;
            } else if (type === 'down') {
                vote.opposeCount++;
            }

            // 发送更新数据到后端的请求，将支持数和反对数保存到数据库
            // 这里需要使用你的具体后端接口来发送请求并更新数据库

            // 示例代码（使用axios发送请求）
            axios.put(`/api/votes/${voteId}`, {
                supportCount: vote.supportCount,
                opposeCount: vote.opposeCount,
            })
            // .then(response => {
            //     // 请求成功的处理逻辑
            //     console.log('更新数据成功');
            // })
            // .catch(error => {
            //     // 请求失败的处理逻辑
            //     console.error('更新数据失败', error);
            // });
        },
    }
};
</script>

<style scoped>
/* 卡片总体样式 */
.voting-card {
    margin: 0 auto;
    background-color: #fff;
    border: none;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
    padding: 10px 30px 10px 10px;
    width: 700px;
    height: auto;
    border-radius: 30px;
    margin-top: 40px;
}

/* 卡片标题样式 */
.text {
    display: flex;
    flex: 1;
    flex-direction: row;
    text-align: left;

}

.right-title {
    font-size: 1.7em;
    margin-right: 15px;
}

.left-title {
    margin-right: 20px;
}

/* 下侧栏 */
.info {
    display: flex;
    align-items: center;
    margin-top: 10px;
    justify-content: flex-start;
    margin: 0px 0px;
    padding-left: 20px;
}

/* 左侧详情栏 */
.details {
    flex: 2.5;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: flex-start;
    text-align: left;
}

.investment {
    color: red;
    font-weight: bold;
    padding-left: 20px;
}

.amount {
    font-size: 2em;
}


/* 右侧投票区样式 */
.voting {
    justify-content: center;
    flex: 1;
    display: flex;
    align-items: center;
    display: flex;
    flex-direction: column;
}


.buttons {
    margin-bottom: 20px;
}

.vote-button {
    background-color: transparent;
    border: none;
    cursor: pointer;
    transition: transform 0.2s;
}

.vote-button.up:hover {
    transform: scale(1.1);
}

.vote-button.down:hover {
    transform: scale(1.1);
}

.vote-percentage {
    margin-left: 10px;
    font-weight: bold;
}



/* 详情卡片的样式 */
.details-card {
    background-color: #fff;
    border: none;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
    padding: 10px 30px 10px 10px;
    width: 700px;
    height: auto;
    border-radius: 30px;
    margin-bottom: 40px;
    display: flex;
    flex-direction: column;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    
}

.content {
    padding-left: 20px;
}

.close-details {
    margin-left: auto;
}

.bottom-div {
    display: flex;
    flex-direction: row;
}

.close-button {
    background-color: transparent;
    cursor: pointer;
    border: none;
    transform: 0.2s;
}

.close-button :hover {
    transform: scale(1.1);
}
</style>
