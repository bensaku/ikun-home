<template>
<div class="body2">
  <div class="main" style="margin: 100px 350px 100px 300px; background-color: #fff; width:600px; height: 400px; padding: 20px; border-radius: 10px">
    <div style="margin: 20px 0; text-align: center;font-size: 24px"><b>实名认证</b></div>
  <el-form ref="form" :model="form" label-width="80px" class="main_form">
  <el-form :inline="true" :model="formInline" class="demo-form-inline">
  <el-form-item label="姓名">
    <el-input v-model="formInline.user" placeholder="姓名"></el-input>
  </el-form-item>
  <el-form-item label="性别">
    <el-select v-model="formInline.sex" placeholder="性别">
      <el-option label="男" value="男"></el-option>
      <el-option label="女" value="女"></el-option>
    </el-select>
  </el-form-item>
  </el-form>

  <el-form :inline="true" :model="formInline" class="demo-form-inline">
  <el-form-item label="民族">
    <el-col :span="6">
    <el-select v-model="formInline.nation" placeholder="民族" class="select">
      <el-option label="汉族" value="汉族"></el-option>
      <el-option label="其他" value="其他"></el-option>
    </el-select>
  </el-col>
    <el-form-item label="地址" style="margin-left: 70px;">
      <el-col :span="50">
    <el-input v-model="formInline.addr" placeholder="地址"></el-input>
   </el-col>
  </el-form-item>
  </el-form-item>
  </el-form>
  <el-form-item label="身份证号">
    <el-co :span="15">
    <el-input v-model="formInline.id" placeholder="身份证号" class="userid"></el-input></el-co>
  </el-form-item>
  <el-form-item label="截至日期">
    <el-col :span="20">
      <el-date-picker type="date" placeholder="选择日期" v-model="form.date1" style="width: 100%;"></el-date-picker>
    </el-col>
  </el-form-item>

  <el-form-item>
    <el-button type="primary" @click="onSubmit" style="margin-left: 140px;">确认</el-button>
    <el-button @click="backshimin">取消</el-button>
  </el-form-item>
</el-form>
  </div>
</div>
</template>

<script>
export default {
  data() {
    return {
      formInline: {
          user: '',
          sex: '',
          nation:'',
          addr:''
        },
      form: {
        date1: '',
        id:'',
        delivery: false,
        type: [],
        desc: ''
      }
    }
  },
  methods: {
    onSubmit() {
      alert('实名认证成功！');
        // 处理实名认证成功的逻辑
        // ...

        // 跳转到登录页面
        this.$router.push('/');
    },
      backshimin(){
        this.$router.push('/RealName');
      },
  }
}
</script>

<style scoped>
.body2{
  position: fixed;
    top: 3%;
    left: 3%;
    right: 3%;
    bottom: 3%;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.4);
    background-image: url(../assets/img/68410857.png);
    background-size: cover;
}
.body2 .main{
   opacity: 0.75;
}
.body2 .main_form >>> .el-form-item__label {
    text-align: right;
    vertical-align: middle;
    float: left;
    font-size: 14px;
    color: #000;
    line-height: 40px;
    padding: 0 12px 0 0;
    box-sizing: border-box;
}
.body2 .userid{
width: 435px;
}
</style>