<template>
    <div class="login clearfix full-background">
      <div class="login-wrap">
        <el-row type="flex" justify="center">
          <el-form ref="loginForm" :model="user" status-icon label-width="80px">
            <h3>登录</h3>
            <hr>
            <div class="icon-container">
                <img src="../assets/img/用户名.png" alt="Custom Icon" class="icon" />
                <input type="text" v-model="user.username" placeholder="请输入用户名" class="input" />
            </div>
            <div class="spacer"></div> <!-- 间隔元素 -->
            <div class="icon-container">
                <img src="../assets/img/密码.png" alt="Custom Icon" class="icon" />
                <input type="text" v-model="user.password" placeholder="请输入密码" class="input" />
            </div>
            <div class="spacer"></div> <!-- 间隔元素 -->
              <el-button type="primary" icon @click="dologin()">登录</el-button>
            <div class="spacer"></div> <!-- 间隔元素 -->
            <div style="display: flex;  justify-content: space-between;">
                <span>
                    <a class="my-link" @click="$router.push('/RegisterView');">立即注册</a>
                </span>
                <span>
                  <a class="my-link" @click="$router.push('/Retrieve');">找回密码</a>
                </span>
            </div>
          </el-form>
        </el-row>
      </div>

      <div class="footer">
        <span class="text">高新智慧社区管理系统</span>
      </div>
    </div>
  </template>
   
  <script>

  import axios from 'axios';
  export default {

    name: "login",
    data() {
      return {
        user: {
          username: "",
          password: "",
        },
      };
    },
    created() {
      // console.log($);
      // console.log("1111");
    },
    methods: {
      dologin() {
        if (!this.user.username) {
          this.$message.error("请输入用户名！");
          return;
        } 
        if (!this.user.password) {
          this.$message.error("请输入密码！");
          return;
        }
        const data = {
          user_no: this.user.username,
          user_password: this.user.password
        };

    // 发送POST请求到后端登录接口
      axios.post('http://localhost:8081/api/login', data)
      .then(response => {
        // 登录成功，处理返回的响应数据
        console.log(response.data); // 输出登录成功的信息
        //this.$message.error("登录成功");
        // 其他操作，例如保存token到本地存储或Vuex状态管理、跳转到其他页面等
      })
      .catch(error => {
       // 登录失败，处理错误信息
       console.log(error.response.data); // 输出登录失败的错误信息
       //this.$message.error("账号或密码错误！");
        // 其他操作，例如显示错误提示等
        console.log(error); 
      });
      
      }
      
  }
  };
  </script>
   
  <!-- Add "scoped" attribute to limit CSS to this component only -->
  <style lang="scss" scoped>
.login {
  position: fixed;
  top: 3%;
  left: 3%;
  right: 3%;
  bottom: 3%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: rgb(255, 255, 255,0.3);
  background-image: url(../assets/img/68410857.png);
  background-size: cover;
  }
  .login .login-wrap {
    background-color: rgba(255,255,255,0.3);
    background-size: cover;
    width: 400px;
    height: 500px;
    margin: 215px auto;
    overflow: hidden;
    padding-top: 10px;
    line-height: 20px;
    display: flex;
    justify-content: center;
    align-items: center;
    border: 2px solid #ffffff; /* 设置边框为2px的白色实线 */
    border-radius: 40px; /* 设置边框的圆角半径为10px */
  }
   
  .login h3 {
    color: white;
    font-size: 24px;
    margin:0 auto;
    width: 60px;
    text-shadow: 2px 2px 4px rgba(0, 0, 0,0.5);
  }
  .login hr {
    background-color: #444;
    margin: 20px auto;
  }
   
  

/***********************/
.login .footer {
  position: absolute;
  bottom: 0px;
  left: 0;
  right: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: transparent;
  color: #fff;
  font-size: 16px;
}

.login .icon-container {
  display: flex;
  align-items: center;
}

.login .icon {
  width: 25px; /* 根据需要设置图标的宽度 */
  height: 25px; /* 根据需要设置图标的高度 */
  margin-right: 10px;
}

.login .input {
  width: 200px;
  height: 25px;
  border-radius: 5px;
  border: none;
  background-color: transparent;
  color: #ffffff; /* 白色文字 */
}

.login .input::placeholder {
    color: #ffffff; /* 白色文字 */
  }

  .login .spacer {
  width: 30px; /* 设置间隔宽度，根据需要进行调整 */
  height: 30px;
}

    .el-button {
    width: 80%;
    margin-left: 10%;
  }

  .my-link {
    color: white; /* 平时的颜色为白色 */
    text-decoration: none; /* 去除下划线 */
    &:hover{
      color: blue; /* 鼠标移上去时的颜色为蓝色 */
    }
  }

 
  </style>