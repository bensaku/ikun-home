<template>
    <div style="position:absolute;right:0;top: 80px;height: 100px;width:80%;z-index: 1;">
        <div class="card-right">
        <h2 class="card-title">
          我管理的家庭
          <button class="increase_btn" @click="showModal">新增家人</button>
        </h2>
        <div style="height: 2px; background-color: rgba(97, 97, 97, 0.647); margin-right: 10px;"></div>
        </div>


    <div class="card" id="problem_card_finish" style="width: 600px; margin-top: 20px;">
        <div class="card-left">
        <h2 class="card-title">
          <input class="card-input1" v-model="name" :readonly="isReadOnly"/>
        </h2>
        <div class="card-data">
          <div class="row" style="margin-top: 50px;">
            <label for="leftData1">身份证号:</label>
            <input class="card-input" type="text" v-model="user_id" :readonly="isReadOnly"/>
          </div>
        </div>
      </div>
      <div style="width: 2px; background-color: rgba(97, 97, 97, 0.647); margin-right: 10px;"></div>
      <div class="card-right">
        <h2 class="card-title">
          账户信息
          <button class="image-button" style="margin-left: 120px;" @click="showModal2">
        <img class="card-icon"  src="../assets/img/叉.png"/>
          </button>
          
        </h2>
          <div class="row" style="margin-top: 45px;">
            <label for="leftData1">账号:</label>
            <input class="card-input" type="text" v-model="user_no" :readonly="isReadOnly"/>
          </div>
      </div>
    </div>


    <div class="card" id="problem_card_finish" style="width: 600px; margin-top: 20px;">
        <div class="card-left">
        <h2 class="card-title">
          <input class="card-input1" v-model="name" :readonly="isReadOnly"/>
        </h2>
        <div class="card-data">
          <div class="row" style="margin-top: 50px;">
            <label for="leftData1">身份证号:</label>
            <input class="card-input" type="text" v-model="user_id" :readonly="isReadOnly"/>
          </div>
        </div>
      </div>
      <div style="width: 2px; background-color: rgba(97, 97, 97, 0.647); margin-right: 10px;"></div>
      <div class="card-right">
        <h2 class="card-title4">
          账户未注册
          <img class="card-icon" src="../assets/img/307感叹号-三角框.png"/>
          <button class="image-button" style="margin-left: 48px;" @click="showModal2">
          <img class="card-icon" src="../assets/img/叉.png"/>
          </button>
        </h2>
          <div class="row" style="margin-top: 45px;">
            <label for="leftData1">请注册并完成实名认证</label>
          </div>
      </div>
    </div>

    <div class="card-right" style="margin-top: 40px;">
        <h2 class="card-title">
          我加入的家庭
        </h2>
        <div style="height: 2px; background-color: rgba(97, 97, 97, 0.647); margin-right: 10px;"></div>
    </div>

    <div class="card" id="problem_card_finish" style="width: 600px; margin-top: 20px;">
        <div class="card-left">
        <h2 class="card-title">
          <input class="card-input1" v-model="name" :readonly="isReadOnly"/>
          <img class="card-icon" src="../assets/img/业主.png"/>
        </h2>
        <div class="card-data">
          <div class="row" style="margin-top: 50px;">
            <label for="leftData1">身份证号:</label>
            <input class="card-input" type="text" v-model="user_id" :readonly="isReadOnly"/>
          </div>
        </div>
      </div>
      <div style="width: 2px; background-color: rgba(97, 97, 97, 0.647); margin-right: 10px;"></div>
      <div class="card-right">
        <h2 class="card-title">
          账户信息
        </h2>
          <div class="row" style="margin-top: 45px;">
            <label for="leftData1">账号:</label>
            <input class="card-input" type="text" v-model="user_no" :readonly="isReadOnly"/>
          </div>
      </div>
    </div>

    <div class="card" id="problem_card_finish" style="width: 600px; margin-top: 20px;">
        <div class="card-left">
        <h2 class="card-title">
          <input class="card-input1" v-model="name" :readonly="isReadOnly"/>
        </h2>
        <div class="card-data">
          <div class="row" style="margin-top: 50px;">
            <label for="leftData1">身份证号:</label>
            <input class="card-input" type="text" v-model="user_id" :readonly="isReadOnly"/>
          </div>
        </div>
      </div>
      <div style="width: 2px; background-color: rgba(97, 97, 97, 0.647); margin-right: 10px;"></div>
      <div class="card-right">
        <h2 class="card-title4">
          账户未注册
          <img class="card-icon" src="../assets/img/307感叹号-三角框.png"/>
        </h2>
          <div class="row" style="margin-top: 45px;">
            <label for="leftData1">请注册并完成实名认证</label>
          </div>
      </div>
    </div>
  
    <div class="modal" v-if="isModalVisible2" style="height: 150px;">
        <h2 class="modal-label1">确认删除该家人?</h2>  
        <div class="modal-buttons" style="margin-top: 60px;">
          <button class="modal-button1" >确认</button>
          <button class="modal-button2" @click="closeModal2">取消</button>
        </div>
    </div>
    

    <div class="modal" v-if="isModalVisible" style="height: 300px;">
        <h2 class="modal-label1">新增家人信息</h2>
        <div class="row" style="margin-top: 40px;">
            <label for="leftData1">身份证号:</label>
            <input class="insert-input" type="text" v-model="insert_id"/>
        </div>
        <div class="row" style="margin-top: 40px;">
            <label style="margin-left: 17px;" for="leftData1">姓名:</label>
            <input style="margin-left: 15px;" class="insert-input" type="text" v-model="insert_name"/>
        </div>   
        <div class="modal-buttons" style="margin-top: 30px;">
          <button class="modal-button1" @click="doinsert">确认</button>
          <button class="modal-button2" @click="closeModal">取消</button>
        </div>
    </div>
</div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        name:'坤坤',
        user_id: 'XXXXXXXXXXXXXXXXXX',
        user_no: 'xxxxxxx',
        isReadOnly: true,
        isModalVisible: false,
        isModalVisible2: false,
        insert_id:'',
        insert_name:''
      };
    },
    methods: {
      showModal() {
      this.isModalVisible = true;
    },
    showModal2() {
      this.isModalVisible2 = true;
    },
    closeModal() {
      this.isModalVisible = false;
    },
    closeModal2() {
      this.isModalVisible2 = false;
    },
    doinsert() {
        if (!this.insert_id) {
          this.$message.error("请输入身份证号！");
          return;
        }
        if (!this.insert_name) {
          this.$message.error("请输入姓名！");
          return;
        }
      },
    handleFileChange(event) {
      const file = event.target.files[0];
      if (file) {
        this.selectedFile = file;
        this.selectedFileName = file.name;
      } else {
        this.selectedFile = null;
        this.selectedFileName = '';
      }
    },
    }


  };
  
  </script>
  <style>
    @import "../assets/style/card.css";

.increase_btn{
  margin-left: 280px;
  background-color: #2f89c5; /* 蓝色背景 */
  border-radius: 15px; /* 圆角矩形 */
  border: none; /* 无边框 */
  font-size: 20px;
  color: #fff; /* 字体颜色为白色 */
  padding: 10px 15px; /* 调整内边距增加按钮大小 */
  transition: background-color 0.3s ease-in-out;
}

.increase_btn:hover {
  background-color: #a9c7e8; /* 淡蓝色背景 */
}

.insert-input {
    width: calc(50% - 8px);
    margin-bottom: 8px;
    border-radius: 5px;
    width: 60%;
    height: 20px;
  }
  .image-button {
  background-color: #ffffff; /* 白色背景 */
  border: none; /* 无边框 */
  padding: 0; /* 去除按钮内边距 */
  cursor: pointer; /* 鼠标指针样式为手型 */
}

  </style>
  