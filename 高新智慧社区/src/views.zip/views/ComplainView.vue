<template>
    <div id="app">

<div style="position:absolute;right:0;top: 80px;height: 100px;width:80%;z-index: 1;">
    <div style="position: absolute;left:40px;top: 30px; color: #667561;font-size: 60px;font-weight: bold;">投诉建议管理</div>
 <SearchComplain style="position:absolute;top:140px;right:30px;"></SearchComplain>
 <div style="position:absolute;top:190px;right: 3%;left: 5%;border: 1px solid rgba(155, 155, 155, 0.3);"></div>
 <div style="position:absolute; top:220px; left: 7%;"><TableComplain></TableComplain></div>
</div>
</div>
</template>

<script>
import TableComplain from '../components/TableComplain.vue';
import SearchComplain from '../components/SearchComplain.vue';
export default {
    components: {
        TableComplain,
        SearchComplain
    }
    
}
</script>

<style>
body{
  margin: 0;
  padding: 0;
}
</style>