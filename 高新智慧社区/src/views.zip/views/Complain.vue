<template>
  <div style="position:absolute;right:0;top: 80px;height: 100px;width:80%;z-index: 1;">
  <div class="card" id="tousu_card_wancheng">
    <div class="card-left">
      <h2 class="card-title">
        历史投诉
        <img class="card-icon" src="../assets/img/tousu.png"/>
      </h2>
      <div class="card-data">
        <div class="row">
          <label for="leftData1">投诉编号:</label>
          <input class="card-input" type="text" v-model="leftData1" :readonly="isReadOnly" />
        </div>
        <div class="row">
          <label for="leftData1">详情:</label>
          <textarea class="card-input2" type="text" v-model="leftData2" :readonly="isReadOnly" />
        </div>
      </div>
    </div>
    <div class="card-right">
      <h2 class="card-title">
        目前状态:
      <input class="card-input1" v-model="rightTitle" />
      </h2>
        <div class="row">
          <label for="leftData1">上报时间:</label>
          <input class="card-input" type="text" v-model="rightData1" :readonly="isReadOnly"/>
          <label for="leftData1">解决时间:</label>
          <input class="card-input" type="text" v-model="rightData2" :readonly="isReadOnly"/>
        </div>
        <div class="row">
          <label for="leftData1">反馈:</label>
          <textarea class="card-input3" type="text" v-model="rightData3" :readonly="isReadOnly"/>
        </div>
    </div>
  </div>

  <div class="card" id="tousu_card_weiwancheng">
    <div class="card-left">
      <h2 class="card-title">
        历史投诉
        <img class="card-icon" src="../assets/img/tousu.png"/>
      </h2>
      <div class="card-data">
        <div class="row">
          <label for="leftData1">投诉编号:</label>
          <input class="card-input" type="text" v-model="leftData2_1" :readonly="isReadOnly"/>
        </div>
        <div class="row">
          <label for="leftData1">详情:</label>
          <textarea class="card-input2" type="text" v-model="leftData2_2" :readonly="isReadOnly"/>
        </div>
      </div>
    </div>
    <div class="card-right">
      <h2 class="card-title3">
        目前状态:
      <input class="card-input4" v-model="rightTitle2" :readonly="isReadOnly"/>
      </h2>
        <div class="row">
          <label for="leftData1">上报时间:</label>
          <input class="card-input" type="text" v-model="rightData2_1" :readonly="isReadOnly"/>
          <label for="leftData1">解决时间:</label>
          <input class="card-input" type="text" v-model="rightData2_2" :readonly="isReadOnly"/>
        </div>
        <div class="row">
          <label for="leftData1">反馈:</label>
          <textarea class="card-input3" type="text" v-model="rightData2_3" :readonly="isReadOnly"/>
        </div>
    </div>
  </div>


  <div class="card_faqi" id="tousu_card_faqi">
    <div class="card-left">
      <h2 class="card-title2">
        发起投诉
        <img class="card-icon" src="../assets/img/tousu2.png"/>
      </h2>
      <div class="card-data_faqi">
        <h>点击右侧按钮发起投诉</h>
      </div>
    </div>
    <div class="card-right">
      <button class="card-button" @click="showModal">
        <img class="card-button-image" src="../assets/img/增加.png"/>
      </button>
      <div class="modal" v-if="isModalVisible">
        <h2 class="modal-label1">投诉</h2>
        <div class="modal-row">
          <label class="modal-row-label1">标题：</label>
          <input class="modal-row-input" type="text" v-model="complaintTitle" />
        </div>
        <div class="modal-row">
          <label class="modal-row-label2">详细描述：</label>
        </div>
        <div class="textarea-row">
          <textarea class="modal-row-textarea" v-model="complaintContent"></textarea>
        </div>        
        
        <div class="modal-buttons">
          <button class="modal-button1" @click="submitComplaint">确认</button>
          <button class="modal-button2" @click="closeModal">取消</button>
        </div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
export default {
  data() {
    return {
      rightTitle: '已处理',
      rightTitle2:'未处理',
      leftData1: '0001',
      leftData2: '狗太吵了',
      rightData1: '2022/6/12',
      rightData2: '2002/6/16',
      rightData3: '抱歉打扰，已解决',
      leftData2_1: '0003',
      leftData2_2: '邻居半夜装修',
      rightData2_1: '2022/6/15',
      rightData2_2: '2022/6/18',
      rightData2_3: '抱歉打扰，已解决',
      isReadOnly: true,
      isModalVisible: false,
      complaintTitle: '',
      complaintContent: '',
    };
  },
  methods: {
    showModal() {
      this.isModalVisible = true;
    },
    closeModal() {
      this.isModalVisible = false;
    },
    submitComplaint() {
      // 处理投诉提交逻辑
    }
  }
};

</script>
<style>
  @import "../assets/style/card.css";
</style>
