<template>
    <div class="container02">
      <div class="border">
        <div class="border-box">
          <h2 class="verification-title">实名认证</h2>
          <div class="button-container">
            <div class="button-wrapper">
                <div class="button-text1">身份证正面</div>
              <button class="big-button left-button">
                <img src="../assets/img/增加.png"  />
              </button>
              
            </div>
            <div class="button-wrapper">
              <div class="button-text2">身份证反面</div>
              <button class="big-button right-button">
                <img src="../assets/img/增加.png"/>
              </button>
              
            </div>
          </div>
          <div class="data-container">
            <div class="data-row1">
            <div class="data-group">
              <span class="data-label">姓名：    </span>
              <input class="data-input" v-model="name" />
            </div>
            <div class="data-group">
              <span class="data-label">性别：</span>
              <input class="data-input" v-model="gender" />
            </div>
            <div class="data-group">
              <span class="data-label">民族：</span>
              <input class="data-input" v-model="ethnicity" />
            </div>
            <div class="data-group">
              <span class="data-label">住址：</span>
              <input class="data-input" v-model="address" />
            </div>
            </div>
            <div class="data-row2">
              <div class="data-group">
              <span class="data-label">身份证号：</span>
              <input class="data-input" v-model="idNumber" />
              </div>
              <div class="data-group">
              <span class="data-label">截至日期：</span>
              <input class="data-input" v-model="expiryDate" />
            </div>
            </div>
          </div>
          <div class="button-container">
            <button class="confirm-button" @click="confirmRegistration">确认</button>
            <button class="cancel-button" @click="backshimin">取消</button>
          </div>
        </div>
      </div>
    </div>
  </template>
  <script>
  export default {
    data() {
      return {
        name: '',
        gender: '',
        ethnicity: '',
        address: '',
        idNumber: '',
        expiryDate: ''
      };
    },
    methods: {
      confirmRegistration() {
        alert('实名认证成功！');
        // 处理实名认证成功的逻辑
        // ...

        // 跳转到登录页面
        this.$router.push('/');
      },
      backshimin(){
        this.$router.push('/RealName');
      },

    },
  };
  </script>
  <style>
  .container02 {
    position: fixed;
    top: 3%;
    left: 3%;
    right: 3%;
    bottom: 3%;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.97);
    background-image: url(../assets/img/68410857.png);
    background-size: cover;
  }
  
  .container02 .border {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  
  .container02 .border-box {
    width: 1350px;
    height: 560px;
    position: relative;
    border: 2px solid #fff;
    border-radius: 25px;
    padding: 20px;
    text-align: center;
    background-color: rgba(255, 255, 255, 0.314);
    backdrop-filter: blur(8px);
    margin: -10px;
  }
  
  .container02 .verification-title {
    font-size: 40px;
    margin: 0 0 20px;
    color: #ffffff;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
  }
  
  .container02 .button-container {
    
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
  }
  
  .container02 .button-wrapper {
    width: 428px;
    height: 270px;
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  .container02 .button-text1{
    padding-left: 20%;
    font-size: 30px;
    color: #ffffff;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    }
  .container02 .button-text2{
    padding-right: 20%;
    font-size: 30px;
    color: #ffffff;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
  }
  .container02 .big-button {
    padding: 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
  }
  
  .container02 .big-button:hover {
    background-color: #ffffff;
  }
  
  .container02 .left-button {
    width: 450px;
    height: 300px;
    margin-left: 30%;
    background-color: #ffffff;
    color: #fff;
  }
  
  .container02 .left-button:hover {
    background-color: #46abda;
  }
  
  .container02 .right-button {
    width: 450px;
    height: 300px;
    margin-right: 30%;
    background-color: #ffffff;
    color: #fff;
  }
  
  .container02 .right-button:hover {
    background-color: #46abda;
  }
  
  .container02 .button-text {
    margin-top: 8px;
  }
  
  .container02 .data-row1 {
margin-top: 3%;
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
}
.container02 .data-row2 {
margin-bottom: 5%;
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
}
.container02 .data-group {
  display: flex;
  align-items: center;
}
.container02 .data-label{
  font-size: 30px;
  color: #ffffff;
}
.container02 .data-input{
  border: 0;
  border-radius: 15px;
  background: transparent;
}
.container02 .data-group:not(:last-child) {
  margin-right: 20px;
}

.container02 .button-container {
  display: flex;
  justify-content: space-between;
}
.container02 .confirm-button {
    position: absolute;
    width: 250px;
    height: 50px;
    bottom: 40px;
    right: 35px;
    border-radius: 50px;
    background-color: #81D3F8;
    color:#558D7F;
    padding: 10px 20px;
    border: none;
    cursor: pointer;
    margin-right: 20%;
    font-size: 20px;
    font-weight: bold;
  }
  
  .container02 .confirm-button:hover {
    background-color: #3d7dd8;
  }
  
  .container02 .cancel-button {
    position: absolute;
    width: 250px;
    height: 50px;
    bottom: 40px;
    right: 35px;
    border-radius: 50px;
    background-color: #ffffff;
    color: #558D7F;
    padding: 10px 20px;
    border: none;
    cursor: pointer;
    font-size: 20px;
    font-weight: bold;
    margin-top: 10%;
  }
  
  .container02 .cancel-button:hover {
    background-color: #d60000;
  }
</style>
  