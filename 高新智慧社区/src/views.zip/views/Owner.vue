<template>
    <div id="app">
      <TopNav style="position:fixed;width:80%;left: 20%;z-index: 2;">
    
  </TopNav>
  <LeftNav style="position:fixed;width:20%;left:0;z-index: 2">
  
  </LeftNav>
  <router-view></router-view>
    </div>
  </template>
  
  <script>
  // 导入组件
  
  import TopNav from './components/TopNav.vue';
  import LeftNav from './components/LeftNav.vue';
  export default {
    name: 'app',
    components: {
      TopNav,
      LeftNav
    }
  }
  </script>