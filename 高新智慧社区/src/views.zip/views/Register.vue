<template>
    <div class="background1">
    <div class="register-container">
        <h1 class="register_title">用户注册</h1>
        <form @submit.prevent="registerUser" class="register-form">
            <div class="form-group">
                <img src="../assets/img/用户名.png" alt="User Icon" class="icon">
                <input class="transparent-input" type="text" id="username" v-model="username" placeholder="请输入用户名" required>
            </div>
            <div class="form-group">
                <img src="../assets/img/密码.png" alt="User Icon" class="icon">
                <input class="transparent-input" type="password" id="password" v-model="password" placeholder="请输入密码" required>
            </div>
            <div class="form-group">
                <img src="../assets/img/密码2.png" alt="User Icon" class="icon">
                <input class="transparent-input" type="password" id="confirmPassword" v-model="confirmPassword" placeholder="请确认密码" required>
            </div>
            <div class="form-group">
                <img src="../assets/img/邮箱.png" alt="User Icon" class="icon">
                <input class="transparent-input" type="text" id="email" v-model="email" placeholder="请输入邮箱" required>
            </div>
            <div class="buttons">
                <button type="submit" class="register-button">注册</button>
                <button type="button" class="quxiao-button" @click="backlogin">取消</button>
            </div>
            
        </form>
    </div>
</div>
</template>

<style>


.background1 {
    position: fixed;
    top: 3%;
    left: 3%;
    right: 3%;
    bottom: 3%;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.4);
    background-image: url(../assets/img/68410857.png);
    background-size: cover;
}

.background1 .register-title {
  color: white;
  text-align: center;
  margin-bottom: 20px;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
}

.background1 .register-container {
    max-width: 400px;
    min-width: 300px;
    margin: auto;
    padding: 20px;
    border-radius: 15px;
    background-color: rgba(255, 255, 255, 0.3);
    box-shadow: 0px 0px 10px gray;
}

.background1 .icon {
  position: absolute;
  top: 50%;
  left: 10px;
  transform: translateY(-50%);
  width: 20px; /* 调整图标的宽度 */
  height: 20px; /* 调整图标的高度 */
}

.background1 .transparent-input {
  background-color: transparent;
  padding-left: 30px;
  margin-left: 50px;
}

.background1 .transparent-input::placeholder {
  color: white; /* 提示文字颜色为白色 */
}

.background1 h1 {
    text-align: center;
    color: white;

}

.background1 .register-form {
    display: flex;
    flex-direction: column;
}

.background1 .form-group {
    margin-bottom: 20px;
    position: relative;
}

.background1 label {
    font-weight: bold;
    position: absolute;
    top: 50%;
    left: 10px;
    transform: translateY(-50%);
    pointer-events: none;
    transition: 0.2s ease-out;
}

.background1 .register-form input[type="text"],
.background1 .register-form input[type="password"] {
    padding: 10px;
    border-radius: 4px;
    border: 1px solid #ccc;
    transition: box-shadow 0.3s ease;
    transition: transform 0.3s ease;
    
}

.background1 .register-form input[type="text"]:focus,
.background1 .register-form input[type="password"]:focus {
  box-shadow: 0 0 5px 2px rgba(0, 0, 0, 0.3);
  transform: scale(1.02);
}

.background1 .active+label {
    top: -10px;
    left: 5px;
    font-size: 12px;
    background-color: #fff;
    padding: 0 4px;
}



.background1 .register-button {
    margin-left: 50px;
    padding: 10px;
    background-color: #007bff;
    color: #fff;
    width: 65px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: box-shadow 0.3s ease, transform 0.3s ease;
}

.background1 .register-button:hover {
  box-shadow: 0 0 5px 2px rgba(255, 255, 255, 0.5);
  transform: scale(1.02);
}

.background1 .register-button:hover {
    background-color: #0056b3;
}

.background1 .quxiao-button{
    margin-left: 50px;
    width: 65px;
    padding: 10px;
    background-color: #ffffff;
    color: #000000;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: box-shadow 0.3s ease, transform 0.3s ease;
}

.background1 .quxiao-button:hover{
    box-shadow: 0 0 5px 2px rgba(255, 255, 255, 0.5);
  transform: scale(1.02);
  background-color: #b5b5b5;
  
}



</style>

<script>
export default {
    name: 'RegisterView',
    data() {
        return {
            username: '',
            password: '',
            confirmPassword: '',
            email: ''
        };
    },
    methods: {
        registerUser() {
            // 在此处编写注册用户的逻辑
            // 可以使用 this.username、this.password、this.confirmPassword 和 this.phone 访问用户输入的值
            console.log('用户名:', this.username);
            console.log('密码:', this.password);
            console.log('确认密码:', this.confirmPassword);
            console.log('邮箱:', this.email);
            // 在这里可以发送注册请求到服务器等等
            this.$router.push('/RealName');
        },
        backlogin(){
            this.$router.push('/');
        },
        clearInput(field) {
            // 清空输入框的值
            this[field] = '';
        }
    }
};
</script>
