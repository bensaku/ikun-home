<template>
  <div  style="position:absolute;right:0;top: 80px;height: 100px;width:80%;z-index: 1;">
  <div class="house-card" id="house_card_shenhezhong">
    <div>
      <h2 class="card-title3">
          审核中
          <img class="card-icon" src="../assets/img/house (1).png"/>
        </h2>
        <div class="row">
          <label for="leftData1">正在审核信息是否吻合,请稍候</label>
        </div>
        <div class="row">
          <label for="leftData1">房屋信息:</label>
        </div>
        <div class="spacer"></div> <!-- 间隔元素 -->
    </div>
    <div style="display: flex;">
        <div class="card-left">
        <div class="card-data">
          <div class="row">
            <label for="leftData1">小区:</label>
            <input class="card-input" type="text" v-model="house_plot1" :readonly="isReadOnly"/>
          </div>
          <div class="row">
            <label for="leftData1">楼栋:</label>
            <input class="card-input" type="text" v-model="house_building1" :readonly="isReadOnly"/>
          </div>
        </div>
      </div>
      <div class="card-right">
          <div class="row">
            <label for="leftData1">单元:</label>
            <input class="card-input" type="text" v-model="house_unit1" :readonly="isReadOnly"/>
          </div>
          <div class="row">
            <label for="leftData1">户号:</label>
            <input class="card-input" type="text" v-model="house_number1" :readonly="isReadOnly"/>
          </div>
      </div>
    </div>
    </div>

    <div class="house-card" id="house_card_yibangding">
    <div>
      <h2 class="card-title">
          已绑定
          <img class="card-icon" src="../assets/img/house (3).png"/>
        </h2>
        <div class="row">
          <label for="leftData1">房屋信息:</label>
        </div>
        <div class="spacer"></div> <!-- 间隔元素 -->
    </div>
    <div style="display: flex;">
        <div class="card-left">
        <div class="card-data">
          <div class="row">
            <label for="leftData1">小区:</label>
            <input class="card-input" type="text" v-model="house_plot2" :readonly="isReadOnly"/>
          </div>
          <div class="row">
            <label for="leftData1">楼栋:</label>
            <input class="card-input" type="text" v-model="house_building2" :readonly="isReadOnly"/>
          </div>
        </div>
      </div>
      <div class="card-right">
          <div class="row">
            <label for="leftData1">单元:</label>
            <input class="card-input" type="text" v-model="house_unit2" :readonly="isReadOnly"/>
          </div>
          <div class="row">
            <label for="leftData1">户号:</label>
            <input class="card-input" type="text" v-model="house_number2" :readonly="isReadOnly"/>
          </div>
      </div>
    </div>
    </div>


  <div class="card_faqi" id="tousu_card_faqi">
    <div class="card-left">
      <h2 class="card-title4">
        绑定房屋
        <img class="card-icon" src="../assets/img/house (2).png"/>
      </h2>
      <div class="card-data_faqi">
        <h>点击右侧＋进行绑定</h>
      </div>
    </div>
    <div class="card-right">
      <button class="card-button" @click="showModal">
        <img class="card-button-image" src="../assets/img/增加.png"/>
      </button>
      <div class="modal2" v-if="isModalVisible">
        <h2 class="modal-label1">房屋绑定</h2>
        <div class="modal-row">
          <label class="modal-row-label1">小区：</label>
          <input class="modal-row-input" type="text" v-model="xiaoqu" />
        </div>
        <div class="modal-row">
          <label class="modal-row-label1">楼栋：</label>
          <input class="modal-row-input" type="text" v-model="loudong" />
        </div>
        <div class="modal-row">
          <label class="modal-row-label1">单元：</label>
          <input class="modal-row-input" type="text" v-model="danyuan" />
        </div>
        <div class="modal-row">
          <label class="modal-row-label1">户号：</label>
          <input class="modal-row-input" type="text" v-model="number" />
        </div>
        <div class="modal-buttons">
          <button class="modal-button1" @click="doinsert">确认</button>
          <button class="modal-button2" @click="closeModal">取消</button>
        </div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
export default {
  data() {
    return {
      house_plot1:'IKUN花园',
      house_building1:'一号楼',
      house_unit1:'二单元',
      house_number1:'501',
      house_plot2:'',
      house_building2:'',
      house_unit2:'',
      house_number2:'',
      isReadOnly: true,
      isModalVisible: false,
      xiaoqu:'',
      danyuan:'',
      loudong:'',
      number:''
    };
  },
  methods: {
    showModal() {
      this.isModalVisible = true;
    },
    closeModal() {
      this.isModalVisible = false;
    },
    doinsert() {
        if (!this.xiaoqu) {
          this.$message.error("请输入小区！");
          return;
        } 
        if (!this.loudong) {
          this.$message.error("请输入楼栋！");
          return;
        }
        if (!this.danyuan) {
          this.$message.error("请输入单元！");
          return;
        }
        if (!this.number) {
          this.$message.error("请输入户号！");
          return;
        }
      }
  }
};

</script>
<style>
  @import "../assets/style/card.css";

  

</style>
