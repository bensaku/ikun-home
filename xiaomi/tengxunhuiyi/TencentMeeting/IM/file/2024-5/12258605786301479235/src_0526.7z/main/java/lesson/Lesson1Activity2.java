package lesson;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;

import androidx.annotation.Nullable;

import com.example.myapplication.R;

public class Lesson1Activity2 extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
//        getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();
        String scheme = intent.getScheme();
        String host = intent.getData().getHost();
        String path = intent.getData().getPath();
        String query = intent.getData().getQuery();
        String b = intent.getData().getQueryParameter("b");
        Uri uri = intent.getData();
        System.out.println("zxl--->action--->"+action);
        System.out.println("zxl--->type--->"+type);
        System.out.println("zxl--->scheme--->"+scheme);
        System.out.println("zxl--->host--->"+host);
        System.out.println("zxl--->path--->"+path);
        System.out.println("zxl--->query--->"+query);
        System.out.println("zxl--->b--->"+b);
        System.out.println("zxl--->uri--->"+uri);
    }
}
