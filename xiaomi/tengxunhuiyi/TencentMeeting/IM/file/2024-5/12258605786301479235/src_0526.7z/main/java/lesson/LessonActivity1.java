package lesson;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.provider.ContactsContract;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.example.myapplication.R;

public class LessonActivity1 extends Activity {
    private CustomReceiver mCustomReceiver = new CustomReceiver();
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.out.println("zxl--->oncreate");
        setContentView(R.layout.main_activity);

        //Intent intent = new Intent(this, Lesson1Activity2.class);
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND+"1");
//        intent.setType("text/html");
        intent.setData(Uri.parse("test2"+"://www.baidu.com?a=1&b=2"));
        intent.setDataAndType(Uri.parse("test2"+"://www.baidu.com?a=1&b=2"),"text/html2");
//        startActivity(intent);

        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS},
                1001);
        intent = new Intent();
        intent.setAction(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:"+135));
        //startActivity(intent);

        intent = new Intent(this, Lesson1Service1.class);
        Bundle bundle = new Bundle();
        bundle.putString("taskName", "task1");
        intent.putExtras(bundle);
//        startService(intent);
//        stopService(intent);
//        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);

        intent = new Intent();
        ComponentName componentName = new ComponentName("com.example.test_app2", "com.example.test_app2.TestService2");
        intent.setComponent(componentName);
//        startService(intent);
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        //adb shell am broadcast -a "test_receiver_action"
        intentFilter.addAction("test_receiver_action");
        registerReceiver(mCustomReceiver, intentFilter);

        ContentResolver contentResolver = getContentResolver();
        String[] projections = new String[] {
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME};
        Cursor cursor = contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                projections,
                null,
                null,
                null
                );
        System.out.println("zxl--->cursor--->"+cursor);
        if (cursor != null) {
            int count = cursor.getCount();
            System.out.println("zxl--->count--->"+count);
            while (cursor.moveToNext()) {
                String id = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME));
                System.out.println("zxl--->id--->" + id);
                System.out.println("zxl--->name--->" + name);

                ContentResolver phoneNumberResolver = getContentResolver();
                Cursor phoneNumberCursor = phoneNumberResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        null,
                        ContactsContract.Contacts._ID + " = ?",
                        new String[]{
                                id
                        },
                        null
                );
                if (phoneNumberCursor != null) {
                    if (phoneNumberCursor.getCount() > 0) {
                        while (phoneNumberCursor.moveToNext()) {
                            String number = phoneNumberCursor.getString(phoneNumberCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                            System.out.println("zxl--->number--->" + number);
                        }
                    }
                    phoneNumberCursor.close();
                }
            }
            cursor.close();
        }

        DataHelper dbHelper = new DataHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        Intent intent1 = new Intent();
        intent1.setAction("test_action");
        sendBroadcast(intent1);
    }

    ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            System.out.println("zxl--->onServiceConnected--->service--->"+service);
//            System.out.println("zxl--->onServiceConnected--->interface--->"+ ITestAidlInterface.Stub.asInterface(service));
//            Lesson1Service1.CustomBinder lesson1Service1 = (Lesson1Service1.CustomBinder) service;
//            lesson1Service1.getService().test();
//            unbindService(serviceConnection);

//            try {
//                int result = ITestAidlInterface.Stub.asInterface(service).add(33, 43);
//                System.out.println("zxl--->onServiceConnected--->result--->"+result);
//            } catch (RemoteException e) {
//                throw new RuntimeException(e);
//            }

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            System.out.println("zxl--->onServiceDisconnected");
        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        System.out.println("zxl--->onRequestPermissionsResult--->"+requestCode+"--->"+permissions[0]+"--->"+grantResults[0]);
    }

    @Override
    protected void onStart() {
        super.onStart();
        System.out.println("zxl--->onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        System.out.println("zxl--->onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        System.out.println("zxl--->onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        System.out.println("zxl--->onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(serviceConnection);
        unregisterReceiver(mCustomReceiver);
        System.out.println("zxl--->onDestroy");
    }
}
