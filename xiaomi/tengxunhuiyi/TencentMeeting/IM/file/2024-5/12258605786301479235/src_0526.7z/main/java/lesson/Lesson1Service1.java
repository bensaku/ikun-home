package lesson;

import android.app.IntentService;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

import androidx.annotation.Nullable;

public class Lesson1Service1 extends IntentService {

    CustomBinder customBinder = new CustomBinder();

    public Lesson1Service1() {
        super("ttt");

    }

    @Override
    public void onCreate() {
        super.onCreate();
        System.out.println("zxl--->service--->onCreate");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        System.out.println("zxl--->service--->onStartCommand");
        return super.onStartCommand(intent, flags, startId);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        System.out.println("zxl--->service--->onBind");
        return customBinder;
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

    }

    @Override
    public boolean onUnbind(Intent intent) {
        System.out.println("zxl--->service--->onUnbind");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        System.out.println("zxl--->service--->onDestroy");
        super.onDestroy();
    }

    public void test() {
        System.out.println("zxl--->service--->test");
    }

    public class CustomBinder extends Binder {
        Lesson1Service1 getService() {
            return Lesson1Service1.this;
        }
    }
}
